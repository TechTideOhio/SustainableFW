// This file serves as an entry point for the package
export { Lenis as default } from './src/lenis'
export * from './src/types'
