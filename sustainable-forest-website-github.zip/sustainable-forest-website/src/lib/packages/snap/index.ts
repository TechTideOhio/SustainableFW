// This file serves as an entry point for the package
export { Snap as default } from './src/snap'
export * from './src/types'
