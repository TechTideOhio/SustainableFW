// This file serves as an entry point for the package
import { Snap } from './src/snap'
globalThis.Snap = Snap
