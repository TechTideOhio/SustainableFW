// This file serves as an entry point for the package
export {
  vueLenisPlugin as default,
  VueLenis as Lenis,
  VueLenis,
} from './src/provider'
export { useLenis } from './src/use-lenis'
