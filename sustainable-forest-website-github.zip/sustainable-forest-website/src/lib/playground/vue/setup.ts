import LenisVue from 'lenis/vue'
import type { App } from 'vue'

export default (app: App) => {
  app.use(LenisVue)
}
