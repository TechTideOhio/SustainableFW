<script setup>
// import { useLenis } from 'lenis/vue'

// const lenis = useLenis((lenis) => {
//   console.log('inner callback', lenis)
// })

// watch(lenis, (lenis) => {
//   console.log('inner lenis', lenis)
// })
</script>

<template>
  <div>Inner</div>
</template>
